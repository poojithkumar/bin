
import java.util.*;

/**
 * 
 */
public interface Color {

    public void fill();

}
