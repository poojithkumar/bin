
import java.util.*;

/**
 * 
 */
public class Square implements Shape {

   
    public void draw() {
        // TODO implement here
	System.out.println("Square Drawn!");
    }

}
