
import java.util.*;

/**
 * 
 */
public class Red implements Color {



    /**
     * 
     */
    public void fill() {
        // TODO implement here
	System.out.println("Filled Red!");
    }

}
