
import java.util.*;

/**
 * 
 */
public class Rectangle implements Shape{

    /**
     * Default constructor
     */
	public void draw(){
	System.out.println("Rectangle Drawn!");
	}
}
