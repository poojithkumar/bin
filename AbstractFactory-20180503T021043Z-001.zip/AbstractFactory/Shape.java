
import java.util.*;

/**
 * 
 */
public interface Shape {

    public void draw();

}
