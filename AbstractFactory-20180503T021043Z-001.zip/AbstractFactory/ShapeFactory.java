
import java.util.*;

/**
 * 
 */
public class ShapeFactory extends AbstractFactory {

    public Shape getShape(String shape) {
        // TODO implement here
	if(shape == null){
         return null;
      }		
      
      else if(shape.equalsIgnoreCase("CIRCLE")){
         return new Circle();
         
      }else if(shape.equalsIgnoreCase("RECTANGLE")){
         return new Rectangle();
         
      }else if(shape.equalsIgnoreCase("SQUARE")){
         return new Square();
      }
      
      return null;

   }
  public Color getColor(String color){
	return null;	
	}
	
}


