
import java.util.*;

/**
 * 
 */
abstract public class AbstractFactory {

   abstract public Shape getShape(String shape);

    /**
     * @return
     */
    abstract public Color getColor(String color);

}
