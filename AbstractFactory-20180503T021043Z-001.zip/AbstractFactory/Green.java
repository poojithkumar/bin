
import java.util.*;

/**
 * 
 */
public class Green implements Color {

    /**
     * Default constructor
     */
    public Green() {
    }

    /**
     * 
     */
    public void fill() {
        // TODO implement here
	System.out.println("Green Filled!");
    }

}
