
import java.util.*;

/**
 * 
 */
public class Circle implements Shape {

    /**
     * Default constructor
     */
    public Circle() {
    }

    /**
     * 
     */
    public void draw() {
        // TODO implement here
	System.out.println("Circle Drawn!");
    }

}
