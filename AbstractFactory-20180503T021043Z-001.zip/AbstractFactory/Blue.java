
import java.util.*;

/**
 * 
 */
public class Blue implements Color {

    /**
     * Default constructor
     */
    public Blue() {
    }

    /**
     * 
     */
    public void fill() {
        // TODO implement here
	System.out.println("Blue Filled!");
    }

}
