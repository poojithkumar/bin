public class SinglePatternDemo {
   public static void main(String[] args) {

      SingleObject object = SingleObject.getInstance();

      //show the message
      object.showMessage();
   }
}
